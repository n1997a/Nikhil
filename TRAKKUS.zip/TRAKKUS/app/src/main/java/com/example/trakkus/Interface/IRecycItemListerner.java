package com.example.trakkus.Interface;

import android.view.View;

public interface IRecycItemListerner {
    public void onItemClickListener(View view, int position);


}
