package com.example.trakkus.Model;

public class Results {
    public String message_id;
}
